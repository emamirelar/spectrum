const COLLECTION_NAME = 'Spectrum';
const SPECTRUM_PREFIX = 'Schemes/sys/color/';
const M3_PREFIX       = 'Schemes/';

const FALLBACKS = {
  'Schemes/Secondary Container': 'Schemes/Secondary',
  'Schemes/On Secondary Container': 'Schemes/On Secondary',
  'Schemes/On Tertiary': 'Schemes/On Primary',
  'Schemes/Tertiary Container': 'Schemes/Tertiary',
  'Schemes/On Tertiary Container': 'Schemes/On Surface',
  'Schemes/On Error': 'Schemes/On Danger',
  'Schemes/On Error Container': 'Schemes/On Danger',
  'Schemes/On Background': 'Schemes/On Surface',
  'Schemes/Surface Tint': 'Schemes/Primary',
  'Schemes/Scrim': 'Schemes/Shadow',
  'Schemes/Inverse Surface': 'Schemes/On Surface',
  'Schemes/Inverse On Surface': 'Schemes/Surface',
  'Schemes/Inverse Primary': 'Schemes/Primary',
  'Schemes/Primary Fixed': 'Schemes/Primary Container',
  'Schemes/On Primary Fixed': 'Schemes/On Primary',
  'Schemes/Primary Fixed Dim': 'Schemes/Primary',
  'Schemes/On Primary Fixed Variant': 'Schemes/On Primary Container',
  'Schemes/Secondary Fixed': 'Schemes/Secondary',
  'Schemes/On Secondary Fixed': 'Schemes/On Secondary',
  'Schemes/Secondary Fixed Dim': 'Schemes/Secondary',
  'Schemes/On Secondary Fixed Variant': 'Schemes/On Secondary',
  'Schemes/Tertiary Fixed': 'Schemes/Tertiary',
  'Schemes/On Tertiary Fixed': 'Schemes/On Primary',
  'Schemes/Tertiary Fixed Dim': 'Schemes/Tertiary',
  'Schemes/On Tertiary Fixed Variant': 'Schemes/On Surface',
  'Schemes/Surface Dim': 'Schemes/Surface',
  'Schemes/Surface Bright': 'Schemes/Surface',
  'Schemes/Surface Container Lowest': 'Schemes/Surface Container Low',
  'Schemes/Surface Container High': 'Schemes/Surface Container',
  'Schemes/Surface Container Highest': 'Schemes/Surface Container',
};

function toTitleCase(kebab) {
  return kebab.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
}

function toKebabCase(titleCase) {
  return titleCase.split(' ').map(w => w.toLowerCase()).join('-');
}

function findCollectionByName(name) {
  const collections = figma.variables.getLocalVariableCollections();
  return collections.find(c => c.name.toLowerCase() === name.toLowerCase());
}

function rename() {
  const collection = findCollectionByName(COLLECTION_NAME);
  if (!collection) {
    figma.notify(`Collection "${COLLECTION_NAME}" not found.`, { error: true });
    return figma.closePlugin();
  }

  let renamed = 0;
  let skipped = 0;

  for (const id of collection.variableIds) {
    const variable = figma.variables.getVariableById(id);
    if (!variable) continue;

    if (variable.name.startsWith(SPECTRUM_PREFIX)) {
      const namePart = variable.name.slice(SPECTRUM_PREFIX.length);
      variable.name = M3_PREFIX + toTitleCase(namePart);
      renamed++;
    } else {
      skipped++;
    }
  }

  figma.notify(`Renamed ${renamed} variable(s) to M3 paths. ${skipped} skipped.`);
  figma.closePlugin();
}

function revert() {
  const collection = findCollectionByName(COLLECTION_NAME);
  if (!collection) {
    figma.notify(`Collection "${COLLECTION_NAME}" not found.`, { error: true });
    return figma.closePlugin();
  }

  let restored = 0;
  let skipped = 0;

  for (const id of collection.variableIds) {
    const variable = figma.variables.getVariableById(id);
    if (!variable) continue;

    if (variable.name.startsWith(M3_PREFIX) && !variable.name.startsWith(SPECTRUM_PREFIX)) {
      const namePart = variable.name.slice(M3_PREFIX.length);
      variable.name = SPECTRUM_PREFIX + toKebabCase(namePart);
      restored++;
    } else {
      skipped++;
    }
  }

  figma.notify(`Reverted ${restored} variable(s) back to Spectrum paths. ${skipped} skipped.`);
  figma.closePlugin();
}

function debug() {
  const collections = figma.variables.getLocalVariableCollections();
  const lines = [];

  for (const col of collections) {
    lines.push(`\n=== Collection: "${col.name}" (${col.variableIds.length} vars) ===`);
    const sample = col.variableIds.slice(0, 10);
    for (const id of sample) {
      const v = figma.variables.getVariableById(id);
      if (v) lines.push(`  ${v.name}`);
    }
    if (col.variableIds.length > 10) {
      lines.push(`  ... and ${col.variableIds.length - 10} more`);
    }
  }

  figma.showUI(
    `<pre style="font:12px/1.5 monospace;padding:16px;white-space:pre-wrap">${lines.join('\n')}</pre>`,
    { width: 500, height: 400 }
  );
}

async function swap() {
  const m3Col = findCollectionByName('M3');
  const specCol = findCollectionByName('Spectrum');

  if (!m3Col) {
    figma.notify('M3 collection not found.', { error: true });
    return figma.closePlugin();
  }
  if (!specCol) {
    figma.notify('Spectrum collection not found.', { error: true });
    return figma.closePlugin();
  }

  await figma.loadAllPagesAsync();

  const m3VarIds = new Set(m3Col.variableIds);

  const specByName = new Map();
  for (const id of specCol.variableIds) {
    const v = figma.variables.getVariableById(id);
    if (v) specByName.set(v.name, v);
  }

  function findMatch(varId) {
    const m3Var = figma.variables.getVariableById(varId);
    if (!m3Var) return null;
    if (specByName.has(m3Var.name)) return specByName.get(m3Var.name);
    const fb = FALLBACKS[m3Var.name];
    if (fb && specByName.has(fb)) return specByName.get(fb);
    return null;
  }

  let swapped = 0;
  let failed = 0;
  const failedVars = new Set();

  function swapPaintArray(node, field) {
    const bindings = node.boundVariables[field];
    if (!bindings || !Array.isArray(bindings)) return;

    const paints = field === 'fills' ? node.fills : node.strokes;
    if (!paints || paints === figma.mixed) return;

    const newPaints = [...paints];
    let changed = false;

    for (let i = 0; i < bindings.length; i++) {
      const alias = bindings[i];
      if (!alias || !alias.id) continue;
      if (!m3VarIds.has(alias.id)) continue;

      const match = findMatch(alias.id);
      if (match && newPaints[i] && newPaints[i].type === 'SOLID') {
        try {
          newPaints[i] = figma.variables.setBoundVariableForPaint(newPaints[i], 'color', match);
          changed = true;
          swapped++;
        } catch (e) {
          failed++;
          const m3v = figma.variables.getVariableById(alias.id);
          if (m3v) failedVars.add(m3v.name + ' (paint error)');
        }
      } else if (!match) {
        failed++;
        const m3v = figma.variables.getVariableById(alias.id);
        if (m3v) failedVars.add(m3v.name);
      }
    }

    if (changed) {
      try {
        if (field === 'fills') node.fills = newPaints;
        else node.strokes = newPaints;
      } catch (e) { /* read-only node */ }
    }
  }

  function swapEffects(node) {
    const bindings = node.boundVariables.effects;
    if (!bindings || !Array.isArray(bindings)) return;

    const effects = node.effects;
    if (!effects || effects.length === 0) return;

    const newEffects = [...effects];
    let changed = false;

    for (let i = 0; i < bindings.length; i++) {
      const alias = bindings[i];
      if (!alias || !alias.id) continue;
      if (!m3VarIds.has(alias.id)) continue;

      const match = findMatch(alias.id);
      if (match && newEffects[i]) {
        try {
          newEffects[i] = figma.variables.setBoundVariableForEffect(newEffects[i], 'color', match);
          changed = true;
          swapped++;
        } catch (e) {
          failed++;
          const m3v = figma.variables.getVariableById(alias.id);
          if (m3v) failedVars.add(m3v.name + ' (effect error)');
        }
      } else if (!match) {
        failed++;
        const m3v = figma.variables.getVariableById(alias.id);
        if (m3v) failedVars.add(m3v.name);
      }
    }

    if (changed) {
      try { node.effects = newEffects; } catch (e) { /* read-only */ }
    }
  }

  function swapScalarFields(node) {
    const bv = node.boundVariables;
    const skipFields = new Set(['fills', 'strokes', 'effects', 'layoutGrids', 'componentProperties']);

    for (const [field, alias] of Object.entries(bv)) {
      if (skipFields.has(field)) continue;
      if (!alias || typeof alias !== 'object' || !alias.id) continue;
      if (Array.isArray(alias)) continue;
      if (!m3VarIds.has(alias.id)) continue;

      const match = findMatch(alias.id);
      if (match) {
        try {
          node.setBoundVariable(field, match);
          swapped++;
        } catch (e) {
          failed++;
          const m3v = figma.variables.getVariableById(alias.id);
          if (m3v) failedVars.add(m3v.name + ' (scalar error)');
        }
      } else {
        failed++;
        const m3v = figma.variables.getVariableById(alias.id);
        if (m3v) failedVars.add(m3v.name);
      }
    }
  }

  function processNode(node) {
    try {
      const bv = node.boundVariables;
      if (bv && Object.keys(bv).length > 0) {
        swapPaintArray(node, 'fills');
        swapPaintArray(node, 'strokes');
        swapEffects(node);
        swapScalarFields(node);
      }
    } catch (e) { /* skip inaccessible nodes */ }

    if ('children' in node) {
      for (const child of node.children) {
        processNode(child);
      }
    }
  }

  let pageNum = 0;
  const totalPages = figma.root.children.length;

  for (const page of figma.root.children) {
    pageNum++;
    figma.notify(`Processing page ${pageNum}/${totalPages}: ${page.name}...`, { timeout: 500 });
    processNode(page);
  }

  const errorList = [...failedVars].sort().map(n => `  - ${n}`).join('\n');
  const summary = [
    `Swap complete.`,
    ``,
    `Swapped: ${swapped} binding(s)`,
    `Failed:  ${failed} binding(s)`,
  ];

  if (failedVars.size > 0) {
    summary.push(``, `Unmatched M3 variables (${failedVars.size}):`, errorList);
  }

  figma.showUI(
    `<pre style="font:13px/1.6 monospace;padding:16px;white-space:pre-wrap">${summary.join('\n')}</pre>`,
    { width: 520, height: 420 }
  );
}

async function createStateLayers() {
  const specCol = findCollectionByName('Spectrum');
  const m3Col = findCollectionByName('M3');

  if (!specCol) {
    figma.notify('Spectrum collection not found.', { error: true });
    return figma.closePlugin();
  }
  if (!m3Col) {
    figma.notify('M3 collection not found.', { error: true });
    return figma.closePlugin();
  }

  const specModeId = specCol.modes[0].modeId;

  const specByName = new Map();
  const existingNames = new Set();
  for (const id of specCol.variableIds) {
    const v = figma.variables.getVariableById(id);
    if (!v) continue;
    existingNames.add(v.name);
    if (v.name.startsWith('Schemes/')) {
      specByName.set(v.name, v);
    }
  }

  function getColorValue(variable) {
    const val = variable.valuesByMode[specModeId];
    if (val && typeof val.r === 'number') return val;
    if (val && val.type === 'VARIABLE_ALIAS') {
      const resolved = figma.variables.getVariableById(val.id);
      if (resolved) {
        const rVal = resolved.valuesByMode[specModeId];
        if (rVal && typeof rVal.r === 'number') return rVal;
      }
    }
    return null;
  }

  function resolveBaseColor(baseName) {
    const schemeName = 'Schemes/' + baseName;
    if (specByName.has(schemeName)) return getColorValue(specByName.get(schemeName));
    const fb = FALLBACKS[schemeName];
    if (fb && specByName.has(fb)) return getColorValue(specByName.get(fb));
    return null;
  }

  const m3StateLayers = [];
  const m3Addons = [];
  for (const id of m3Col.variableIds) {
    const v = figma.variables.getVariableById(id);
    if (!v) continue;
    if (v.name.startsWith('State Layers/')) m3StateLayers.push(v);
    else if (v.name.startsWith('Add-ons/')) m3Addons.push(v);
  }

  let created = 0;
  let skipped = 0;
  const unresolved = [];

  for (const m3Var of m3StateLayers) {
    if (existingNames.has(m3Var.name)) { skipped++; continue; }

    const parts = m3Var.name.split('/');
    if (parts.length !== 3) { skipped++; continue; }

    const baseName = parts[1];
    const opMatch = parts[2].match(/Opacity-(\d+)/);
    if (!opMatch) { skipped++; continue; }
    const alpha = parseInt(opMatch[1]) / 100;

    const baseColor = resolveBaseColor(baseName);
    if (!baseColor) {
      unresolved.push(m3Var.name);
      continue;
    }

    try {
      const newVar = figma.variables.createVariable(m3Var.name, specCol, 'COLOR');
      newVar.setValueForMode(specModeId, { r: baseColor.r, g: baseColor.g, b: baseColor.b, a: alpha });
      newVar.scopes = ['FRAME_FILL', 'SHAPE_FILL', 'STROKE_COLOR'];
      created++;
      existingNames.add(m3Var.name);
    } catch (e) {
      unresolved.push(m3Var.name + ' (create error: ' + e.message + ')');
    }
  }

  for (const m3Var of m3Addons) {
    if (existingNames.has(m3Var.name)) { skipped++; continue; }

    const surfaceVar = specByName.get('Schemes/Surface');
    if (!surfaceVar) {
      unresolved.push(m3Var.name + ' (no Surface variable)');
      continue;
    }
    const surfaceColor = getColorValue(surfaceVar);
    if (!surfaceColor) {
      unresolved.push(m3Var.name + ' (could not resolve Surface)');
      continue;
    }

    try {
      const newVar = figma.variables.createVariable(m3Var.name, specCol, 'COLOR');
      newVar.setValueForMode(specModeId, surfaceColor);
      created++;
      existingNames.add(m3Var.name);
    } catch (e) {
      unresolved.push(m3Var.name + ' (create error: ' + e.message + ')');
    }
  }

  const summary = [
    'State Layers creation complete.',
    '',
    `Created: ${created} variable(s)`,
    `Skipped: ${skipped} (already exist)`,
  ];

  if (unresolved.length > 0) {
    summary.push('', `Unresolved (${unresolved.length}):`, ...unresolved.map(n => '  - ' + n));
  }

  summary.push('', 'Next step: re-run "2. Swap M3 to Spectrum" to rebind the remaining layers.');

  figma.showUI(
    `<pre style="font:13px/1.6 monospace;padding:16px;white-space:pre-wrap">${summary.join('\n')}</pre>`,
    { width: 520, height: 420 }
  );
}

switch (figma.command) {
  case 'debug':  debug();  break;
  case 'rename': rename(); break;
  case 'revert': revert(); break;
  case 'swap':   swap();   break;
  case 'createStateLayers': createStateLayers(); break;
  default: figma.closePlugin();
}
