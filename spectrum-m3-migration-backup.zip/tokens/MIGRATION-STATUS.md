# M3-to-Spectrum Variable Migration -- Status & Handoff

**Date:** 2026-02-27
**Figma file:** Contains M3 components bound to M3 variable collection
**Goal:** Rebind all M3 variable references to equivalent Spectrum variables

---

## Current Progress

| Metric | Count |
|--------|-------|
| Bindings successfully swapped | 24,657 |
| Bindings still using M3 variables | 4,082 |
| Unmatched M3 variables | 34 (State Layers + Add-ons) |

The 34 unmatched variables are all `State Layers/*/Opacity-*` variants and
`Add-ons/Section background`. A new plugin command has been written to create
these in the Spectrum collection, but **has not been run yet**.

---

## Next Steps (in Figma)

### 1. Re-import the plugin

Plugins > Development > Import plugin from manifest...

Point to:

```
packages/core/src/tokens/figma-swap-plugin/
```

This picks up the new "5. Create Spectrum State Layers" command.

### 2. Run "5. Create Spectrum State Layers"

This reads every M3 `State Layers/*` and `Add-ons/*` variable, resolves the
matching Spectrum base color (using direct name match or fallback), and creates
a new COLOR variable in the Spectrum collection with the correct RGBA value.

Expected output: **~148 new variables created**.

### 3. Re-run "2. Swap M3 to Spectrum (rebind all layers)"

The 4,082 previously failed bindings should now find their Spectrum match.
Unmatched count should drop to near zero.

### 4. Clean up

Once you confirm all bindings are swapped:

- Delete the M3 variable collection from the Figma file
- Optionally run "4. Revert M3 to Spectrum paths" if any Spectrum variables
  were left in M3-style naming from earlier experiments

---

## File Inventory

All files live under `packages/core/src/tokens/`.

### `figma-swap-plugin/code.js` (454 lines)

Custom Figma plugin with 5 commands:

| Menu label | Command | What it does |
|------------|---------|--------------|
| 1. Debug - List variable names | `debug` | Lists all collections and their first 10 variable names |
| 2. Swap M3 to Spectrum | `swap` | Traverses every node in every page; rebinds M3 variables to Spectrum equivalents |
| 3. Rename Spectrum to M3 paths | `rename` | Renames `Schemes/sys/color/kebab-name` to `Schemes/Title Case` |
| 4. Revert M3 to Spectrum paths | `revert` | Reverses the rename above |
| 5. Create Spectrum State Layers | `createStateLayers` | Creates State Layer + Add-on variables in Spectrum collection |

Key constants defined at the top:

- `COLLECTION_NAME` = `'Spectrum'`
- `SPECTRUM_PREFIX` = `'Schemes/sys/color/'`
- `M3_PREFIX` = `'Schemes/'`
- `FALLBACKS` = object mapping M3 names with no direct Spectrum match to their closest Spectrum equivalent

### `figma-swap-plugin/manifest.json` (18 lines)

Plugin manifest. Name: "Spectrum M3 Tools", ID: `spectrum-m3-tools-local`.

### `mapping.json` (660 lines)

Spectrum design system token definitions. Sections:

- `unops.color` -- UNOPS brand palette
- `spectrum.sys.color` -- core semantic colors (primary, secondary, surface, etc.)
- `spectrum.sys.state-layers` -- **NEW** -- 147 State Layer tokens (49 base colors x 3 opacity levels: 0.08, 0.10, 0.16)
- `spectrum.sys.add-ons` -- **NEW** -- `section-background` token
- `spectrum.color` -- aliases referencing `spectrum.sys.color`
- `spectrum.font` / `spectrum.shape` -- typography and shape tokens

### `m3-to-spectrum-mapping.json` (271 lines)

Reference mapping from M3 variable paths to Spectrum equivalents. Each entry has:

- `spectrum` -- the Spectrum variable path
- `status` -- `exact` (direct match), `fallback` (closest substitute), or `missing`
- `fallback` -- (when status is fallback) the suggested Spectrum variable

### `M3/` directory

Original M3 token source files (`Light.tokens.json`, etc.) used as reference for
understanding M3 variable structure, naming conventions, and State Layer patterns.

---

## Troubleshooting

- **Plugin not appearing in Figma:** Re-import via Plugins > Development > Import plugin from manifest. Point to the `figma-swap-plugin/` folder.
- **"Collection not found" error:** Make sure the Figma file has both an "M3" and a "Spectrum" variable collection loaded.
- **Swap reports 0 changes:** The M3 collection must be local (not a remote library reference). If variables come from an external library, you need to import them into the file first.
- **State Layers command creates 0 variables:** The M3 collection must contain `State Layers/*` variables. Run the Debug command first to verify.

---

## Conversation Reference

This work was done across a Cursor AI chat session. The full transcript is at:

```
~/.cursor/projects/.../agent-transcripts/a18de7e4-2714-4f76-b4fb-0bbaf21d3262.jsonl
```

To resume, open the `tokens/` folder in Cursor and reference this document.
